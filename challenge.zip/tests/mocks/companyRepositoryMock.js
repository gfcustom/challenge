// Simula un repositorio Company con Jest

class CompanyRepositoryMock {
  constructor() {
    this.companies = new Map();

    // Jest mocks para spy en métodos
    this.findByCuit = jest.fn(this.findByCuit.bind(this));
    this.save = jest.fn(this.save.bind(this));
    this.findAdheredLastMonth = jest.fn(this.findAdheredLastMonth.bind(this));
  }

  async findByCuit(cuit) {
    if(this.companies.has(cuit)) {
      return this.companies.get(cuit);
    }
    return null;
  }

  async save(company) {
    this.companies.set(company.cuit, company);
    return company;
  }

  async findAdheredLastMonth(fromFecha, limit = 10, offset = 0) {
    // Devuelve todas las companias cuya adhesionDate >= fromFecha
    const filtered = Array.from(this.companies.values())
      .filter(c => c.adhesionDate >= fromFecha)
      .sort((a,b) => b.adhesionDate - a.adhesionDate);
    return filtered.slice(offset, offset + limit);
  }
}

module.exports = CompanyRepositoryMock;
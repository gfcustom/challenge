class TransferRepositoryMock {
  constructor() {
    this.transfers = [];
    this.save = jest.fn(this.save.bind(this));
    this.findTransfersFromDate = jest.fn(this.findTransfersFromDate.bind(this));
  }

  async save(transfer) {
    this.transfers.push(transfer);
    return transfer;
  }

  async findTransfersFromDate(fromFecha, limit = 100, offset = 0) {
    const filtered = this.transfers
      .filter(t => t.date >= fromFecha)
      .sort((a, b) => b.date - a.date);
    return filtered.slice(offset, offset + limit);
  }
}

module.exports = TransferRepositoryMock;